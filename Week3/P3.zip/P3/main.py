from calc_app.calc_app import CalcApp

def main():
    app = CalcApp()
    app.run_app()

if __name__ == "__main__":
    main()